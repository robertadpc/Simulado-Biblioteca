const express = require('express');
const app = express();
const mysql = require('mysql');
const cors = require('cors');

app.use(express.json());
app.use(cors());

const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "root",
    database: "simulado_bruno_souza",
});

app.post('/api/login', (req, res) => {
    const { username, password, perfil } = req.body;

    sqlSelect = "SELECT * FROM usuario WHERE login = ? AND senha = ? AND perfil = ?";

    db.query(sqlSelect, [username, password, perfil], (err, result) => {
        if (err) {
            console.log(err);
        } else {
            if (result.length > 0) {
                res.send({
                    logged: true,
                    perfil: perfil,
                })
            } else {
                res.send({ msg: "User not Found" })
            };
        };
    });
})

app.listen(3001, () => {
    console.log('Running on port: 3001')
});